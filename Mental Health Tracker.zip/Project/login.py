import streamlit as st
import sqlite3
import bcrypt  # For secure password hashing
import subprocess

# Database connection and table creation (if not already exists)
conn = sqlite3.connect('login.db')
cursor = conn.cursor()

def create_table():
    cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                        email TEXT PRIMARY KEY,
                        password TEXT NOT NULL
                    )''')
    conn.commit()

create_table()

# Session state variables (consider using a more secure mechanism)
if 'username' not in st.session_state:
    st.session_state.username = ''
if 'loggedin' not in st.session_state:
    st.session_state.loggedin = False

def login():
    email = st.text_input('Email Address')
    password = st.text_input('Password', type='password')  # Mask password input
    login_button = st.button('Login')

    if login_button:
        try:
            cursor.execute("SELECT COUNT(*) FROM users")  # Check for existing users
            user_count = cursor.fetchone()[0]

            if user_count == 0:
                st.warning('No registered users yet. Please register first.')
            else:
                cursor.execute("SELECT * FROM users WHERE email=?", (email,))
                user = cursor.fetchone()

                if user and bcrypt.checkpw(password.encode('utf-8'), user[1]):  # Verify hashed password
                    st.session_state.username = user[0]
                    st.session_state.loggedin = True
                    st.success('Login successful!')

                    # Redirect to landing.py after successful login
                    subprocess.Popen(["streamlit", "run", "main.py"])

                else:
                    st.warning('Incorrect email or password.')
        except Exception as e:
            st.error(f'An error occurred: {e}')

def register():
    email = st.text_input('Email Address')
    password = st.text_input('Password', type='password')  # Mask password input
    confirm_password = st.text_input('Confirm Password', type='password')  # Mask password input
    register_button = st.button('Register')

    if register_button:
        # Validate user input (email format, password strength, etc.)
        if not all([email, password, confirm_password]):
            st.warning('Please fill in all required fields.')
            return

        if password != confirm_password:
            st.warning('Passwords do not match.')
            return

        # Hash password before storing
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        try:
            cursor.execute("INSERT INTO users (email, password) VALUES (?, ?)",
                           (email, hashed_password.decode('utf-8'))) # Decode the hashed password to store it as a string
            conn.commit()
            st.success('Registration successful! You can now log in.')
        except Exception as e:
            st.error(f'An error occurred during registration: {e}')

def main():
    st.title('Login Page')

    # Show login or registration options based on user preference
    login_choice = st.radio('Login or Register', ('Login', 'Register'))

    if login_choice == 'Login':
        login()
    else:
        register()

if __name__ == '__main__':
    main()
