import streamlit as st
import subprocess

def main():
    st.title("AI Based Mental Health Tracker")

    # Sidebar
    st.sidebar.title("Options")
    option = st.sidebar.radio("Select", ["Home", "Mental Health Check-In", "Visualization", "Guidance","Chatbot","Music"])

    # Main content
    if option == "Home":
        show_home()
    elif option == "Mental Health Check-In":
        subprocess.Popen(["streamlit", "run", "main1.py"])
    elif option == "Visualization":
        subprocess.Popen(["streamlit", "run", "visualization.py"])
    elif option == "Guidance":
        subprocess.Popen(["streamlit", "run", "guidance.py"])
    elif option == "Chatbot":
        subprocess.Popen(["streamlit", "run", "app.py"])
    elif option == "Music":
        subprocess.Popen(["streamlit", "run", "sound_therapy.py"])

def show_home():
    #st.header("AI Based Mental Health Tracker")
    st.write("AI Based Mental Health Tracker is a web application designed to help individuals track their mental health over time. "
             "By completing regular check-ins and recording their feelings, users can gain insights into their emotional patterns and identify areas for improvement.")

    st.header("Features")
    st.markdown("""
    - Interactive questionnaires to help users track their mental health
    - Visualization of mental health data over time
    - Personalized guidance based on user data and artificial intelligence
    """)

    st.header("How to Use")
    st.markdown("""
    1. Navigate to the MoodLens website
    2. Select the "Mental Health Check-In" option to complete a questionnaire about your current mental state
    3. View your mental health data over time in the "Visualization" section of the app
    4. Get personalized guidance from an AI-powered virtual psychologist in the "Guidance" section
    """)

if __name__ == "__main__":
    main()
