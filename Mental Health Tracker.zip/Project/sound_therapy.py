import streamlit as st
import pandas as pd
import sqlite3
import subprocess
import random

# Function to play music
def play_music(audio_file):
    st.audio(audio_file, format='audio/mp3', start_time=0)

# Function to display sound therapy options
def show_sound_therapy():
    # Sidebar options
    st.sidebar.title("Options")
    option = st.sidebar.radio("Select", ["Home", "Mental Health Check-In", "Visualization", "Guidance"])

    # Main content title
    st.title("Sound Therapy")

    # Connect to the database
    conn = sqlite3.connect("mental_health.db")
    cursor = conn.cursor()

    # Retrieve data from the database
    cursor.execute("SELECT * FROM mental_health")
    rows = cursor.fetchall()
    df = pd.DataFrame(rows, columns=[desc[0] for desc in cursor.description])

    # Close the database connection
    conn.close()

    # Filter out rows with NaN mood values
    df = df.dropna(subset=['feeling'])

    # Display cards named by human emotions
    mood_options = df['feeling'].unique()
    for mood in mood_options:
        # Add a colorful header for each mood
        st.markdown(f'<div style="background-color:#ffe6e6;padding:10px;border-radius:10px;"><h2 style="color:#333333;">{str(mood).capitalize()} Mood</h2></div>', unsafe_allow_html=True)
        # Load corresponding audio file
        if mood == 10.0:
            audio_file = "mixkit-feeling-happy-5.mp3"
        else:
            audio_file = "mixkit-feeling-happy-5.mp3"

        # Generate a unique key for the button
        button_key = f"play_music_{str(mood)}"
        # Play music button
        if st.button(f"Play Music for {str(mood).capitalize()} Mood", key=button_key, help=f"Click to play music for {str(mood).capitalize()} mood"):
            play_music(audio_file)
            # Display a random motivational quote for the mood
            st.markdown(f'<div style="padding:20px; background-color:#cceeff; border-radius:10px;"><h3 style="color:#0066cc;">{random.choice(motivational_quotes[mood])}</h3></div>', unsafe_allow_html=True)

    # Sidebar option navigation
    if option == "Home":
        show_home()
    elif option == "Mental Health Check-In":
        subprocess.Popen(["streamlit", "run", "main1.py"])
    elif option == "Visualization":
        subprocess.Popen(["streamlit", "run", "visualization.py"])
    elif option == "Guidance":
        subprocess.Popen(["streamlit", "run", "guidance.py"])
    elif option == "Chatbot":
        subprocess.Popen(["streamlit", "run", "app.py"])
    elif option == "Music":
        subprocess.Popen(["streamlit", "run", "sound_therapy.py"])
# Function to display home page content
def show_home():
    st.title(" ")
    # st.write(
    #     "AI Based Mental Health Tracker is a web application designed to help individuals track their mental health over time. "
    #     "By completing regular check-ins and recording their feelings, users can gain insights into their emotional patterns and identify areas for improvement.")
    #
    # # Features section
    # st.header("Features")
    # st.markdown("""
    # - Interactive questionnaires to help users track their mental health
    # - Visualization of mental health data over time
    # - Personalized guidance based on user data and artificial intelligence
    # """)
    #
    # # How to Use section
    # st.header("How to Use")
    # st.markdown("""
    # 1. Navigate to the MoodLens website
    # 2. Select the "Mental Health Check-In" option to complete a questionnaire about your current mental state
    # 3. View your mental health data over time in the "Visualization" section of the app
    # 4. Get personalized guidance from an AI-powered virtual psychologist in the "Guidance" section
    # """)

# Dictionary of motivational quotes for each mood
motivational_quotes = {
    8.0: [
        "Believe you can and you're halfway there. - Theodore Roosevelt",
        "The only way to do great work is to love what you do. - Steve Jobs",
        "Don't watch the clock; do what it does. Keep going. - Sam Levenson"
    ],
    9.0: [
        "The best preparation for tomorrow is doing your best today. - H. Jackson Brown Jr.",
        "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill"
    ],
    10.0: [
        "Your limitation—it's only your imagination.",
        "Push yourself, because no one else is going to do it for you."
    ]
}

if __name__ == "__main__":
    show_sound_therapy()
