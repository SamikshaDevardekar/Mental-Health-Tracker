import streamlit as st
import pandas as pd
import plotly.express as px
import sqlite3
import subprocess

st.sidebar.title("Options")
option = st.sidebar.radio("Select", ["Home", "Mental Health Check-In", "Visualization", "Guidance","Chatbot","Music"])

st.title("Mental Health Visualization")

DATABASE_PATH = "mental_health.db"

def connect_to_db(database_path):
    try:
        conn = sqlite3.connect(database_path)
        return conn
    except sqlite3.Error as e:
        st.error(f"Error connecting to the database: {e}")
        return None

def read_data(database_path):
    conn = connect_to_db(database_path)
    if conn is None:
        return pd.DataFrame()
    else:
        df = pd.read_sql_query("SELECT * FROM mental_health ORDER BY date DESC", conn)
        conn.close()  # Close the connection after use
        return df

def delete_data():
    if st.button("Delete all data"):
        if st.checkbox("Confirm deletion"):
            with sqlite3.connect(DATABASE_PATH) as conn:
                c = conn.cursor()
                c.execute("DROP TABLE IF EXISTS mental_health")
            st.write("All data has been deleted from the database.")

def show_visualization(database_path, test_option):
    df = read_data(database_path)
    if df.empty:
        return

    if test_option == "Mood Test":
        df = df[['date', 'feeling', 'serenity','satisfaction','creativity','motivation']]
        title = "Mood, Serenity, Satisfaction,Creativity and Motivation Scores Over Time"
        x_label = "Date"
        y_label = "Score"
    elif test_option == "Sleep Quality Test":
        df = df[['date', 'sleep', 'productivity','optimism','challenges','focus']]
        title = "Sleep Quality, Productivity, Optimism, Challenges and Focus Scores Over Time"
        x_label = "Date"
        y_label = "Score"
    elif test_option == "Enjoyment Test":
        df = df[['date', 'enjoyment','stress','balance','connection']]
        title = "Enjoyment, Stress, Balance, Connection Scores Over Time"
        x_label = "Date"
        y_label = "Score"

    with sqlite3.connect(database_path) as conn:
        # Line plot for individual metrics over time
        fig1 = px.line(df, x='date', y=df.columns[1:], line_shape="spline")
        fig1.update_layout(xaxis_tickformat='%Y-%m-%d', title=title, xaxis_title=x_label, yaxis_title=y_label)

        # Average scores by category
        average_scores = df.mean()
        df2 = pd.DataFrame({"category": average_scores.index, "average": average_scores.values})
        fig2 = px.bar_polar(df2, r="average", theta="category", template="plotly_dark")
        fig2.update_traces(opacity=0.7)
        fig2.update_layout(title="Average Mental Health Scores by Category")

    st.write("## Mental Health Data")
    st.dataframe(df)
    delete_data()
    st.plotly_chart(fig1)
    st.plotly_chart(fig2)

def show_home():
    st.write("AI Based Mental Health Tracker is a web application designed to help individuals track their mental health over time. "
             "By completing regular check-ins and recording their feelings, users can gain insights into their emotional patterns and identify areas for improvement.")

    st.header("Features")
    st.markdown("""
    - Interactive questionnaires to help users track their mental health
    - Visualization of mental health data over time
    - Personalized guidance based on user data and artificial intelligence
    """)

    st.header("How to Use")
    st.markdown("""
    1. Navigate to the MoodLens website
    2. Select the "Mental Health Check-In" option to complete a questionnaire about your current mental state
    3. View your mental health data over time in the "Visualization" section of the app
    4. Get personalized guidance from an AI-powered virtual psychologist in the "Guidance" section
    """)

def run_app():
    if option == "Home":
        test_option = st.radio("Select Test", ["Mood Test", "Sleep Quality Test", "Enjoyment Test"])
        show_visualization(DATABASE_PATH, test_option)
    elif option == "Mental Health Check-In":
        subprocess.Popen(["streamlit", "run", "main1.py"])
    elif option == "Visualization":
        test_option = st.radio("Select Test", ["Mood Test", "Sleep Quality Test", "Enjoyment Test"])
        show_visualization(DATABASE_PATH, test_option)
    elif option == "Guidance":
        subprocess.Popen(["streamlit", "run", "guidance.py"])
    elif option == "Chatbot":
        subprocess.Popen(["streamlit", "run", "app.py"])
    elif option == "Music":
        subprocess.Popen(["streamlit", "run", "sound_therapy.py"])

if __name__ == "__main__":
    run_app()
