import streamlit as st
import subprocess

def main():
    # Center the title
    st.markdown("<h1 style='text-align: center;'>Welcome to My App</h1>", unsafe_allow_html=True)

    # Display image
    image = "landing_logo.jpg"
    st.image(image, use_column_width=True)

    # Center the button
    st.markdown("""
        <style>
            .stButton>button {
                display: block;
                margin: 0 auto;
            }
        </style>
    """, unsafe_allow_html=True)

    if st.button("Get Started"):
        # Call function from main1.py
        subprocess.Popen(["streamlit", "run", "main.py"])

if __name__ == "__main__":
    main()
