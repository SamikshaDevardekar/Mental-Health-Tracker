#database_manager.py
import sqlite3

# Path to the SQLite database file (customize as needed)
DATABASE_PATH = "mental_health.db"

def create_connection():
    """Create a connection to the SQLite database."""
    conn = sqlite3.connect(DATABASE_PATH)
    return conn

def create_table():
    """Create the mental_health table if it doesn't exist."""
    conn = create_connection()
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS mental_health (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 date TEXT,
                 feeling INTEGER,
                 serenity INTEGER,
                 satisfaction INTEGER,
                 creativity INTEGER,
                 motivation INTEGER,
                 sleep INTEGER,
                 productivity INTEGER,
                 optimism INTEGER,
                 challenges INTEGER,
                 focus INTEGER,
                 enjoyment INTEGER,
                 stress INTEGER,
                 balance INTEGER,
                 connection INTEGER,
                 average REAL
                 )''')
    conn.commit()
    conn.close()

def add_entry(date, feeling, serenity,satisfaction, creativity, motivation, sleep, productivity, optimism, challenges, focus, enjoyment, stress, balance, connection, average):
    """Add a new entry to the mental_health table."""
    conn = create_connection()
    c = conn.cursor()
    c.execute("INSERT INTO mental_health (date, feeling, serenity, satisfaction, creativity, motivation, sleep, productivity, optimism, challenges, focus, enjoyment, stress, balance, connection, average) VALUES (?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?)",
              (date, feeling, serenity,satisfaction, creativity,motivation, sleep, productivity, optimism, challenges, focus, enjoyment, stress, balance, connection, average))
    conn.commit()
    conn.close()


def connect_to_db():
    return None