import streamlit as st
import pandas as pd
import sqlite3
from modules import database_manager
import subprocess

DATABASE_PATH = "mental_health.db"

st.sidebar.title("Options")
option = st.sidebar.radio("Select", ["Home", "Mental Health Check-In", "Visualization", "Guidance","Chatbot","Music"])

     # Main content
def show_home():
    pass


if option == "Home":
    show_home()
elif option == "Mental Health Check-In":
    subprocess.Popen(["streamlit", "run", "main1.py"])
elif option == "Visualization":
    subprocess.Popen(["streamlit", "run", "visualization.py"])
elif option == "Guidance":
    subprocess.Popen(["streamlit", "run", "guidance.py"])
elif option == "Chatbot":
    subprocess.Popen(["streamlit", "run", "app.py"])
elif option == "Music":
    subprocess.Popen(["streamlit", "run", "sound_therapy.py"])

def show_home():
    #st.header("AI Based Mental Health Tracker")
    st.write("AI Based Mental Health Tracker is a web application designed to help individuals track their mental health over time. "
             "By completing regular check-ins and recording their feelings, users can gain insights into their emotional patterns and identify areas for improvement.")

    st.header("Features")
    st.markdown("""
    - Interactive questionnaires to help users track their mental health
    - Visualization of mental health data over time
    - Personalized guidance based on user data and artificial intelligence
    """)

    st.header("How to Use")
    st.markdown("""
    1. Navigate to the MoodLens website
    2. Select the "Mental Health Check-In" option to complete a questionnaire about your current mental state
    3. View your mental health data over time in the "Visualization" section of the app
    4. Get personalized guidance from an AI-powered virtual psychologist in the "Guidance" section
    """)


def show_guidance():
    st.write("## Mental Health Guidances")


    # Provide links to external resources
    st.write("**Additional Resources:**")
    st.write("- National Alliance on Mental Illness (NAMI): https://www.nami.org/Home")
    st.write("- MentalHealth.gov: https://www.samhsa.gov/mental-health")
    st.write("- Crisis Text Line: Text HOME to 741741")
    st.write("- The Jed Foundation: https://www.jedfoundation.org/")  # Added resource
    st.write(
                    "**Additional Guidance:** If you're feeling down or anxious, "
                    "consider relaxation techniques like deep breathing or meditation. "
                    "Regular exercise can also improve mood. Here are some resources "
                    "to help you get started: "
                )
    st.write("- Relaxation Techniques: https://psycnet.apa.org/record/2014-56671-026")
    st.write("- Meditation Apps: https://www.headspace.com/([Headspace]), https://www.calm.com/")

            # Provide self-care tips (general)
    st.write("**Self-Care Tips:**")
    st.write(
            "- **Prioritize sleep:** Aim for 7-8 hours of sleep per night for optimal mental health."
        )
    st.write(
            "- **Maintain a healthy diet:** Eating nutritious foods can improve mood and energy levels."
        )
    st.write(
            "- **Connect with others:** Social interaction is important for mental well-being."
        )
    st.write(
            "- **Engage in activities you enjoy:** Participating in hobbies can reduce stress and improve mood."
        )
    st.write(
            "- **Seek professional help:** If you're struggling to cope with mental health challenges, don't hesitate to seek professional help from a therapist or counselor.")

    st.write("**Extra Guidance:**")
    st.write(
        "- **Practice mindfulness:** Mindfulness techniques, such as meditation or yoga, can help reduce stress and increase self-awareness."
    )
    st.write(
        "- **Limit screen time:** Excessive screen time, especially before bed, can negatively impact sleep quality and overall well-being. Try to establish screen-free periods during the day."
    )
    st.write(
        "- **Establish a routine:** Creating a daily routine can provide structure and stability, which can be beneficial for mental health. Include activities that promote relaxation and enjoyment."
    )
    st.write(
        "- **Express gratitude:** Take time each day to reflect on things you're grateful for. Practicing gratitude can improve mood and overall outlook on life."
    )
    st.write(
        "- **Set boundaries:** Learn to say no to activities or commitments that may overwhelm you. Setting boundaries is essential for maintaining mental and emotional health."
    )

# Call the function to show the guidance
show_guidance()
