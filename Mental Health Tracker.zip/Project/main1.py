import streamlit as st
import datetime
import plotly.graph_objects as go
from database_manager import add_entry
import subprocess


st.title('Mental Health Check-In')

st.sidebar.title("Options")
option = st.sidebar.radio("Select", ["Home", "Mental Health Check-In", "Visualization", "Guidance","Chatbot","Music"])

     # Main content
def show_home():
    pass


if option == "Home":
    show_home()
elif option == "Mental Health Check-In":
    subprocess.Popen(["streamlit", "run", "main1.py"])
elif option == "Visualization":
    subprocess.Popen(["streamlit", "run", "visualization.py"])
elif option == "Guidance":
    subprocess.Popen(["streamlit", "run", "guidance.py"])
elif option == "Chatbot":
    subprocess.Popen(["streamlit", "run", "app.py"])
elif option == "Music":
    subprocess.Popen(["streamlit", "run", "sound_therapy.py"])

def show_home():
    #st.header("AI Based Mental Health Tracker")
    st.write("AI Based Mental Health Tracker is a web application designed to help individuals track their mental health over time. "
             "By completing regular check-ins and recording their feelings, users can gain insights into their emotional patterns and identify areas for improvement.")

    st.header("Features")
    st.markdown("""
    - Interactive questionnaires to help users track their mental health
    - Visualization of mental health data over time
    - Personalized guidance based on user data and artificial intelligence
    """)

    st.header("How to Use")
    st.markdown("""
    1. Navigate to the MoodLens website
    2. Select the "Mental Health Check-In" option to complete a questionnaire about your current mental state
    3. View your mental health data over time in the "Visualization" section of the app
    4. Get personalized guidance from an AI-powered virtual psychologist in the "Guidance" section
    """)


# Define functions for each test
def test_1():
    st.subheader("Test 1: Mood Test")
    mood = st.slider("How are you feeling today? (0 = Terrible, 10 = Great)", 0, 10)
    serenity = st.slider("How would you rate your level of serenity today? (0 = Poorly, 10 = Very well)", 0, 10)
    satisfaction =st.slider("How satisfied are you with your energy levels today? (0 = Very low, 10 = Very high)",0, 10)
    creativity =st.slider("How would you rate your level of creativity today? (0 = Not creative at all, 10 = Extremely creative)",0, 10)
    motivation =st.slider("Rate your level of motivation today. (0 = Very low, 10 = Very high)",0,10)
    return mood, serenity, satisfaction, creativity, motivation

def test_2():
    st.subheader("Test 2: Sleep Quality Test")
    sleep_quality = st.slider("How well did you sleep last night? (0 = Poorly, 10 = Very well)", 0, 10)
    productivity = st.slider("How productive were you today? (0 = Not at all, 10 = Extremely productive)", 0, 10)
    optimism = st.slider("Rate your level of optimism for the day ahead. (0 = Very pessimistic, 10 = Very optimistic)", 0, 10)
    challenges = st.slider("How well did you handle challenges or setbacks today? (0 = Very poorly, 10 = Very effectively)",0, 10 )
    focus = st.slider("Rate your level of engagement or focus in your activities today. (0 = Very distracted, 10 = Very focused)", 0, 10)
    return sleep_quality, productivity, optimism, challenges, focus

def test_3():
    st.subheader("Test 3: Enjoyment Test")
    enjoyment = st.slider("How much did you enjoy your day today? (0 = Not at all, 10 = Very much)", 0, 10)
    stress =st.slider("How well did you manage stress or anxiety today? (0 = Very poorly, 10 = Very effectively)", 0, 10)
    balance=st.slider("How balanced do you feel emotionally today? (0 = Very imbalanced, 10 = Very balanced)", 0, 10)
    connection =st.slider("How connected do you feel with others today? (0 = Very isolated, 10 = Very connected)", 0, 10)
    return enjoyment,stress,balance,connection

# Title and header
st.header('Choose a Test')

# Display options for different tests
test_option = st.radio("Select Test", ["Mood Test", "Sleep Quality Test", "Enjoyment Test"])

# Based on user selection, call the corresponding test function
if test_option == "Mood Test":
    mood, serenity, satisfaction, creativity, motivation = test_1()
elif test_option == "Sleep Quality Test":
    sleep_quality, productivity, optimism, challenges, focus = test_2()
elif test_option == "Enjoyment Test":
    enjoyment,stress,balance,connection = test_3()

# Calculate average score if applicable
if test_option == "Mood Test":
    average_score = (mood + serenity + satisfaction + creativity + motivation) / 5
elif test_option == "Sleep Quality Test":
    average_score = (sleep_quality + productivity + optimism + challenges + focus) / 5
elif test_option == "Enjoyment Test":
    average_score = (enjoyment + stress + balance + connection) /4

# Display the average score
st.subheader('Your average mental health score for this test is:')
st.write(average_score)

# Gauge chart to visualize the average score
fig = go.Figure(go.Indicator(
    domain={'x': [0, 1], 'y': [0, 1]},
    value=average_score,
    mode="gauge+number",
    title={'text': "Mental Health Score"},
    gauge={
        'axis': {'range': [0, 10]},
        'steps': [
            {'range': [0, 2], 'color': "red"},
            {'range': [2, 4], 'color': "orange"},
            {'range': [4, 6], 'color': "yellow"},
            {'range': [6, 8], 'color': "lightgreen"},
            {'range': [8, 10], 'color': "green"}],
        'threshold': {'line': {'color': "black", 'width': 4}, 'thickness': 0.75, 'value': average_score}}))

st.plotly_chart(fig, use_container_width=True, height=50)

# Get the current date and time
now = datetime.datetime.now()
date_string = now.strftime('%Y-%m-%d')

# Submit button to save data
if st.button('Submit to your Daily MindLens Tracker'):
    add_entry(date=date_string, feeling=mood if test_option == "Mood Test" else None,
              serenity=serenity if test_option == "Mood Test" else None,
              satisfaction=satisfaction if test_option == "Mood Test" else None,
              creativity=creativity if test_option == "Mood Test" else None,
              motivation=motivation if test_option == "Mood Test" else None,
              sleep=sleep_quality if test_option == "Sleep Quality Test" else None,
              productivity=productivity if test_option == "Sleep Quality Test" else None,
              optimism=optimism if test_option == "Sleep Quality Test" else None,
              challenges=challenges if test_option == "Sleep Quality Test" else None,
              focus=focus if test_option == "Sleep Quality Test" else None,
              enjoyment=enjoyment if test_option == "Enjoyment Test" else None,
              stress=stress if test_option == "Enjoyment Test" else None,
              balance=balance if test_option == "Enjoyment Test" else None,
              connection=connection if test_option == "Enjoyment Test" else None,
              average=average_score)
    st.success("Your mental health check-in has been submitted!")
